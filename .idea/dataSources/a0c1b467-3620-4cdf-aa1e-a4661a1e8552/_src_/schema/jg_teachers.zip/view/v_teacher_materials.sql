CREATE VIEW `v_teacher_materials` AS
  SELECT
    `jg_teachers`.`t_teacher_baseinfo`.`name`         AS `name`,
    `jg_teachers`.`t_teaching_material`.`id`          AS `id`,
    `jg_teachers`.`t_teaching_material`.`user_id`     AS `user_id`,
    `jg_teachers`.`t_teaching_material`.`course_name` AS `course_name`,
    `jg_teachers`.`t_teaching_material`.`semester`    AS `semester`,
    `jg_teachers`.`t_teaching_material`.`type`        AS `type`,
    `jg_teachers`.`t_teaching_material`.`file`        AS `file`,
    `jg_teachers`.`t_teaching_material`.`file_time`   AS `file_time`
  FROM (`jg_teachers`.`t_teaching_material`
    JOIN `jg_teachers`.`t_teacher_baseinfo`
      ON ((`jg_teachers`.`t_teaching_material`.`user_id` = `jg_teachers`.`t_teacher_baseinfo`.`user_id`)))