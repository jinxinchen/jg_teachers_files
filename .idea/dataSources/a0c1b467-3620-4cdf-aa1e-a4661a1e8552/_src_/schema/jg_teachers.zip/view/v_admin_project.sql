CREATE VIEW `v_admin_project` AS
  SELECT
    `jg_teachers`.`t_scientific`.`user_id`       AS `user_id`,
    `jg_teachers`.`t_scientific`.`head_name`     AS `head_name`,
    `jg_teachers`.`t_teacher_baseinfo`.`user_id` AS `user_id_base`,
    `jg_teachers`.`t_teacher_baseinfo`.`name`    AS `name`,
    `jg_teachers`.`t_scientific`.`id`            AS `id`
  FROM (`jg_teachers`.`t_scientific`
    JOIN `jg_teachers`.`t_teacher_baseinfo`
      ON ((`jg_teachers`.`t_scientific`.`head_name` = `jg_teachers`.`t_teacher_baseinfo`.`name`)))