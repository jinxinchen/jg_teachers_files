CREATE VIEW `v_teachers_accounts` AS
  SELECT
    `jg_teachers`.`t_users`.`account`      AS `account`,
    `jg_teachers`.`t_users`.`create_time`  AS `create_time`,
    `jg_teachers`.`t_users_role`.`role_id` AS `role_id`,
    `jg_teachers`.`t_users_role`.`id`      AS `id`,
    `jg_teachers`.`t_users_role`.`user_id` AS `user_id`
  FROM (`jg_teachers`.`t_users`
    JOIN `jg_teachers`.`t_users_role` ON ((`jg_teachers`.`t_users_role`.`user_id` = `jg_teachers`.`t_users`.`id`)))