CREATE VIEW `v_degree_info` AS
  SELECT
    `jg_teachers`.`t_users`.`id`                           AS `id`,
    `jg_teachers`.`t_teacher_baseinfo`.`socialFunction`    AS `socialFunction`,
    `jg_teachers`.`t_teacher_baseinfo`.`research`          AS `research`,
    `jg_teachers`.`t_teacher_baseinfo`.`for_class`         AS `for_class`,
    `jg_teachers`.`t_teacher_baseinfo`.`academicSecretary` AS `academicSecretary`,
    `jg_teachers`.`t_teacher_baseinfo`.`adminFunction`     AS `adminFunction`,
    `jg_teachers`.`t_teacher_baseinfo`.`tutor_class`       AS `tutor_class`,
    `jg_teachers`.`t_teacher_baseinfo`.`is_tutor`          AS `is_tutor`,
    `jg_teachers`.`t_teacher_baseinfo`.`major`             AS `major`,
    `jg_teachers`.`t_teacher_baseinfo`.`status`            AS `status`,
    `jg_teachers`.`t_educate_degree`.`educate_degree_name` AS `educate_degree_name`,
    `jg_teachers`.`t_educate_degree`.`educate_degree_time` AS `educate_degree_time`,
    `jg_teachers`.`t_educate_degree`.`educate_degree_src`  AS `educate_degree_src`,
    `jg_teachers`.`t_educate_degree`.`educate_time`        AS `educate_time`,
    `jg_teachers`.`t_educate_degree`.`is_mentor`           AS `is_mentor`,
    `jg_teachers`.`t_educate_degree`.`mentor_evidence_src` AS `mentor_evidence_src`
  FROM ((`jg_teachers`.`t_users`
    JOIN `jg_teachers`.`t_teacher_baseinfo`
      ON ((`jg_teachers`.`t_teacher_baseinfo`.`user_id` = `jg_teachers`.`t_users`.`id`))) JOIN
    `jg_teachers`.`t_educate_degree` ON ((`jg_teachers`.`t_educate_degree`.`user_id` = `jg_teachers`.`t_users`.`id`)))